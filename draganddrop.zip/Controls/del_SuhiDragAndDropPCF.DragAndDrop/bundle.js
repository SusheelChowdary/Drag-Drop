/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./DragAndDrop/index.ts":
/*!******************************!*\
  !*** ./DragAndDrop/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.DragAndDrop = void 0;\nvar groupArray = __webpack_require__(/*! group-array */ \"./node_modules/group-array/index.js\");\n/* eslint no-unused-vars : \"off\" */\nvar DragAndDrop = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function DragAndDrop() {}\n  DragAndDrop.prototype.init = function (context, notifyOutputChanged, state, container) {\n    context.mode.trackContainerResize(true);\n    // Add control initialization code\n    this.mainContainer = document.createElement(\"div\");\n    this.mainContainer.id = \"DargAndDrop\";\n    container.appendChild(this.mainContainer);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  DragAndDrop.prototype.updateView = function (context) {\n    var _this = this;\n    this.mainContainer.innerHTML = \"\";\n    this.contextObj = context;\n    if (!context.parameters.DataSet.loading) {\n      // Get sorted columns on View\n      var statusColums_1 = this.getDiffrentStatusColums(context);\n      var availablecolumns_1 = this.getSortedColumnsOnView(context);\n      var groupbyStatusItems = this.groupByStatus(context, statusColums_1);\n      console.log(groupbyStatusItems);\n      if (statusColums_1.length > 0) {\n        groupbyStatusItems.forEach(function (element) {\n          var statusName = element.Name.split(\":\")[0];\n          var statusValue = element.Name.split(\":\")[1];\n          var statuDiv = document.createElement(\"div\");\n          statuDiv.className = \"status\";\n          statuDiv.style.width = 1 / statusColums_1.length * 100 - 1 + \"%\";\n          statuDiv.id = statusValue;\n          statuDiv.innerHTML = \"<h1>\" + statusName + \"</h1>\";\n          var records = element.Records;\n          records.forEach(function (record) {\n            var columnelement = document.createElement(\"div\");\n            columnelement.className = \"column\";\n            columnelement.id = record.getRecordId();\n            columnelement.draggable = true;\n            var cardElement = document.createElement(\"div\");\n            cardElement.className = \"card\";\n            availablecolumns_1.forEach(function (column) {\n              if (availablecolumns_1[0] == column && column.name != \"statuscode\") {\n                cardElement.innerHTML += \"<h3>\" + record.getFormattedValue(column.name);\n                +\"</h3>\";\n              } else if (column.name != \"statuscode\") {\n                cardElement.innerHTML += \"<p>\" + column.displayName + \" : \" + record.getFormattedValue(column.name);\n                +\"</p>\";\n              }\n            });\n            columnelement.appendChild(cardElement);\n            statuDiv.appendChild(columnelement);\n          });\n          _this.mainContainer.appendChild(statuDiv);\n        });\n        this.draggableFunctions(context);\n      }\n    }\n  };\n  DragAndDrop.prototype.draggableFunctions = function (context) {\n    var _this = this;\n    var draggables = document.querySelectorAll(\".column\");\n    var containers = document.querySelectorAll(\".status\");\n    draggables.forEach(function (draggable) {\n      draggable.addEventListener(\"dragstart\", function () {\n        draggable.classList.add(\"dragging\");\n      });\n      draggable.addEventListener(\"dragend\", function () {\n        draggable.classList.remove(\"dragging\");\n      });\n    });\n    containers.forEach(function (container) {\n      container.addEventListener(\"dragover\", function (e) {\n        e.preventDefault();\n        var draggable = document.querySelector(\".dragging\");\n        if (draggable != null) {\n          container.appendChild(draggable);\n          _this.callWebApi(context, container.id, draggable.id);\n        }\n      });\n    });\n  };\n  DragAndDrop.prototype.callWebApi = function (context, statusid, recordid) {\n    var entityName = context.parameters.DataSet.getTargetEntityType();\n    var data = {};\n    data[\"statuscode\"] = parseInt(statusid);\n    context.webAPI.updateRecord(entityName, recordid, data).then(function (response) {\n      console.log(response);\n    }, function (errorResponse) {\n      // Error handling code here - record failed to be created\n      console.log(errorResponse);\n    });\n  };\n  DragAndDrop.prototype.getSortedColumnsOnView = function (context) {\n    if (!context.parameters.DataSet.columns) {\n      return [];\n    }\n    var columns = context.parameters.DataSet.columns.filter(function (columnItem) {\n      // some column are supplementary and their order is not > 0\n      return columnItem.order >= 0;\n    });\n    // Sort those columns so that they will be rendered in order\n    columns.sort(function (a, b) {\n      return a.order - b.order;\n    });\n    return columns;\n  };\n  DragAndDrop.prototype.groupByStatus = function (context, statusColums) {\n    var groupedData = new Array();\n    this.contextObj = context;\n    var diffrentStatus = new Array();\n    if (!context.parameters.DataSet.columns) {\n      return [];\n    }\n    var gridParam = context.parameters.DataSet;\n    if (gridParam.sortedRecordIds.length > 0) {\n      var groupbyData = {};\n      statusColums.forEach(function (element) {\n        var formmatedValue = element.split(\":\")[0];\n        var groupByStatus = new Array();\n        for (var _i = 0, _a = gridParam.sortedRecordIds; _i < _a.length; _i++) {\n          var currentRecordId = _a[_i];\n          if (gridParam.records[currentRecordId].getFormattedValue(\"statuscode\") == formmatedValue) {\n            groupByStatus.push(gridParam.records[currentRecordId]);\n          }\n        }\n        var groupByelemnt = {\n          Name: element,\n          Records: groupByStatus\n        };\n        groupedData.push(groupByelemnt);\n      });\n    }\n    return groupedData;\n  };\n  DragAndDrop.prototype.getDiffrentStatusColums = function (context) {\n    this.contextObj = context;\n    var diffrentStatus = new Array();\n    if (!context.parameters.DataSet.columns) {\n      return [];\n    }\n    var gridParam = context.parameters.DataSet;\n    if (gridParam.sortedRecordIds.length > 0) {\n      for (var _i = 0, _a = gridParam.sortedRecordIds; _i < _a.length; _i++) {\n        var currentRecordId = _a[_i];\n        diffrentStatus.push(gridParam.records[currentRecordId].getFormattedValue(\"statuscode\") + \":\" + gridParam.records[currentRecordId].getValue(\"statuscode\"));\n      }\n    }\n    var distinctStatus = diffrentStatus.filter(function (n, i) {\n      return diffrentStatus.indexOf(n) === i;\n    });\n    return distinctStatus;\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  DragAndDrop.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  DragAndDrop.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return DragAndDrop;\n}();\nexports.DragAndDrop = DragAndDrop;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DragAndDrop/index.ts?");

/***/ }),

/***/ "./node_modules/arr-flatten/index.js":
/*!*******************************************!*\
  !*** ./node_modules/arr-flatten/index.js ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
eval("/*!\n * arr-flatten <https://github.com/jonschlinkert/arr-flatten>\n *\n * Copyright (c) 2014-2017, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nmodule.exports = function (arr) {\n  return flat(arr, []);\n};\nfunction flat(arr, res) {\n  var i = 0,\n    cur;\n  var len = arr.length;\n  for (; i < len; i++) {\n    cur = arr[i];\n    Array.isArray(cur) ? flat(cur, res) : res.push(cur);\n  }\n  return res;\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/arr-flatten/index.js?");

/***/ }),

/***/ "./node_modules/for-in/index.js":
/*!**************************************!*\
  !*** ./node_modules/for-in/index.js ***!
  \**************************************/
/***/ ((module) => {

"use strict";
eval("/*!\n * for-in <https://github.com/jonschlinkert/for-in>\n *\n * Copyright (c) 2014-2017, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nmodule.exports = function forIn(obj, fn, thisArg) {\n  for (var key in obj) {\n    if (fn.call(thisArg, obj[key], key, obj) === false) {\n      break;\n    }\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/for-in/index.js?");

/***/ }),

/***/ "./node_modules/for-own/index.js":
/*!***************************************!*\
  !*** ./node_modules/for-own/index.js ***!
  \***************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("/*!\n * for-own <https://github.com/jonschlinkert/for-own>\n *\n * Copyright (c) 2014-2017, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nvar forIn = __webpack_require__(/*! for-in */ \"./node_modules/for-in/index.js\");\nvar hasOwn = Object.prototype.hasOwnProperty;\nmodule.exports = function forOwn(obj, fn, thisArg) {\n  forIn(obj, function (val, key) {\n    if (hasOwn.call(obj, key)) {\n      return fn.call(thisArg, obj[key], key, obj);\n    }\n  });\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/for-own/index.js?");

/***/ }),

/***/ "./node_modules/get-value/index.js":
/*!*****************************************!*\
  !*** ./node_modules/get-value/index.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("/*!\n * get-value <https://github.com/jonschlinkert/get-value>\n *\n * Copyright (c) 2014-2018, Jon Schlinkert.\n * Released under the MIT License.\n */\n\nvar isObject = __webpack_require__(/*! isobject */ \"./node_modules/isobject/index.js\");\nmodule.exports = function (target, path, options) {\n  if (!isObject(options)) {\n    options = {\n      default: options\n    };\n  }\n  if (!isValidObject(target)) {\n    return typeof options.default !== 'undefined' ? options.default : target;\n  }\n  if (typeof path === 'number') {\n    path = String(path);\n  }\n  var isArray = Array.isArray(path);\n  var isString = typeof path === 'string';\n  var splitChar = options.separator || '.';\n  var joinChar = options.joinChar || (typeof splitChar === 'string' ? splitChar : '.');\n  if (!isString && !isArray) {\n    return target;\n  }\n  if (isString && path in target) {\n    return isValid(path, target, options) ? target[path] : options.default;\n  }\n  var segs = isArray ? path : split(path, splitChar, options);\n  var len = segs.length;\n  var idx = 0;\n  do {\n    var prop = segs[idx];\n    if (typeof prop === 'number') {\n      prop = String(prop);\n    }\n    while (prop && prop.slice(-1) === '\\\\') {\n      prop = join([prop.slice(0, -1), segs[++idx] || ''], joinChar, options);\n    }\n    if (prop in target) {\n      if (!isValid(prop, target, options)) {\n        return options.default;\n      }\n      target = target[prop];\n    } else {\n      var hasProp = false;\n      var n = idx + 1;\n      while (n < len) {\n        prop = join([prop, segs[n++]], joinChar, options);\n        if (hasProp = prop in target) {\n          if (!isValid(prop, target, options)) {\n            return options.default;\n          }\n          target = target[prop];\n          idx = n - 1;\n          break;\n        }\n      }\n      if (!hasProp) {\n        return options.default;\n      }\n    }\n  } while (++idx < len && isValidObject(target));\n  if (idx === len) {\n    return target;\n  }\n  return options.default;\n};\nfunction join(segs, joinChar, options) {\n  if (typeof options.join === 'function') {\n    return options.join(segs);\n  }\n  return segs[0] + joinChar + segs[1];\n}\nfunction split(path, splitChar, options) {\n  if (typeof options.split === 'function') {\n    return options.split(path);\n  }\n  return path.split(splitChar);\n}\nfunction isValid(key, target, options) {\n  if (typeof options.isValid === 'function') {\n    return options.isValid(key, target);\n  }\n  return true;\n}\nfunction isValidObject(val) {\n  return isObject(val) || Array.isArray(val) || typeof val === 'function';\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/get-value/index.js?");

/***/ }),

/***/ "./node_modules/group-array/index.js":
/*!*******************************************!*\
  !*** ./node_modules/group-array/index.js ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("\n\nvar split = __webpack_require__(/*! split-string */ \"./node_modules/split-string/index.js\");\nvar flatten = __webpack_require__(/*! arr-flatten */ \"./node_modules/arr-flatten/index.js\");\nvar union = __webpack_require__(/*! union-value */ \"./node_modules/union-value/index.js\");\nvar forOwn = __webpack_require__(/*! for-own */ \"./node_modules/for-own/index.js\");\nvar typeOf = __webpack_require__(/*! kind-of */ \"./node_modules/kind-of/index.js\");\nvar get = __webpack_require__(/*! get-value */ \"./node_modules/get-value/index.js\");\nfunction groupFn(arr, props) {\n  if (arr == null) {\n    return [];\n  }\n  if (!Array.isArray(arr)) {\n    throw new TypeError('group-array expects an array.');\n  }\n  if (arguments.length === 1) {\n    return arr;\n  }\n  var args = flatten([].slice.call(arguments, 1));\n  var groups = groupBy(arr, args[0]);\n  for (var i = 1; i < args.length; i++) {\n    toGroup(groups, args[i]);\n  }\n  return groups;\n}\nfunction groupBy(arr, prop, key) {\n  var groups = {};\n  for (var i = 0; i < arr.length; i++) {\n    var obj = arr[i];\n    var val = void 0;\n\n    // allow a function to modify the object\n    // and/or return a val to use\n    if (typeof prop === 'function') {\n      val = prop.call(groups, obj, key);\n    } else {\n      val = get(obj, prop);\n    }\n    switch (typeOf(val)) {\n      case 'undefined':\n        break;\n      case 'string':\n      case 'number':\n      case 'boolean':\n        union(groups, escape(String(val)), obj);\n        break;\n      case 'object':\n      case 'array':\n        eachValue(groups, obj, val);\n        break;\n      case 'function':\n        throw new Error('invalid argument type: ' + key);\n    }\n  }\n  return groups;\n}\nfunction eachValue(groups, obj, val) {\n  if (Array.isArray(val)) {\n    val.forEach(key => {\n      union(groups, escape(key), obj);\n    });\n  } else {\n    forOwn(val, (v, key) => {\n      union(groups, escape(key), obj);\n    });\n  }\n}\nfunction toGroup(groups, prop) {\n  forOwn(groups, (val, key) => {\n    if (!Array.isArray(val)) {\n      groups[key] = toGroup(val, prop, key);\n    } else {\n      groups[key] = groupBy(val, prop, key);\n    }\n  });\n  return groups;\n}\nfunction escape(str) {\n  var opts = {\n    strict: false,\n    keepEscaping: true,\n    keepDoubleQuotes: true,\n    keepSingleQuotes: true\n  };\n  try {\n    return split(str, opts).join('\\\\.');\n  } catch (err) {\n    return str;\n  }\n}\n\n/**\n * Expose `groupArray`\n */\n\nmodule.exports = groupFn;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/group-array/index.js?");

/***/ }),

/***/ "./node_modules/is-plain-object/index.js":
/*!***********************************************!*\
  !*** ./node_modules/is-plain-object/index.js ***!
  \***********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("/*!\n * is-plain-object <https://github.com/jonschlinkert/is-plain-object>\n *\n * Copyright (c) 2014-2017, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nvar isObject = __webpack_require__(/*! isobject */ \"./node_modules/isobject/index.js\");\nfunction isObjectObject(o) {\n  return isObject(o) === true && Object.prototype.toString.call(o) === '[object Object]';\n}\nmodule.exports = function isPlainObject(o) {\n  var ctor, prot;\n  if (isObjectObject(o) === false) return false;\n\n  // If has modified constructor\n  ctor = o.constructor;\n  if (typeof ctor !== 'function') return false;\n\n  // If has modified prototype\n  prot = ctor.prototype;\n  if (isObjectObject(prot) === false) return false;\n\n  // If constructor does not have an Object-specific method\n  if (prot.hasOwnProperty('isPrototypeOf') === false) {\n    return false;\n  }\n\n  // Most likely a plain Object\n  return true;\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/is-plain-object/index.js?");

/***/ }),

/***/ "./node_modules/isobject/index.js":
/*!****************************************!*\
  !*** ./node_modules/isobject/index.js ***!
  \****************************************/
/***/ ((module) => {

"use strict";
eval("/*!\n * isobject <https://github.com/jonschlinkert/isobject>\n *\n * Copyright (c) 2014-2017, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nmodule.exports = function isObject(val) {\n  return val != null && typeof val === 'object' && Array.isArray(val) === false;\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/isobject/index.js?");

/***/ }),

/***/ "./node_modules/kind-of/index.js":
/*!***************************************!*\
  !*** ./node_modules/kind-of/index.js ***!
  \***************************************/
/***/ ((module) => {

eval("var toString = Object.prototype.toString;\nmodule.exports = function kindOf(val) {\n  if (val === void 0) return 'undefined';\n  if (val === null) return 'null';\n  var type = typeof val;\n  if (type === 'boolean') return 'boolean';\n  if (type === 'string') return 'string';\n  if (type === 'number') return 'number';\n  if (type === 'symbol') return 'symbol';\n  if (type === 'function') {\n    return isGeneratorFn(val) ? 'generatorfunction' : 'function';\n  }\n  if (isArray(val)) return 'array';\n  if (isBuffer(val)) return 'buffer';\n  if (isArguments(val)) return 'arguments';\n  if (isDate(val)) return 'date';\n  if (isError(val)) return 'error';\n  if (isRegexp(val)) return 'regexp';\n  switch (ctorName(val)) {\n    case 'Symbol':\n      return 'symbol';\n    case 'Promise':\n      return 'promise';\n\n    // Set, Map, WeakSet, WeakMap\n    case 'WeakMap':\n      return 'weakmap';\n    case 'WeakSet':\n      return 'weakset';\n    case 'Map':\n      return 'map';\n    case 'Set':\n      return 'set';\n\n    // 8-bit typed arrays\n    case 'Int8Array':\n      return 'int8array';\n    case 'Uint8Array':\n      return 'uint8array';\n    case 'Uint8ClampedArray':\n      return 'uint8clampedarray';\n\n    // 16-bit typed arrays\n    case 'Int16Array':\n      return 'int16array';\n    case 'Uint16Array':\n      return 'uint16array';\n\n    // 32-bit typed arrays\n    case 'Int32Array':\n      return 'int32array';\n    case 'Uint32Array':\n      return 'uint32array';\n    case 'Float32Array':\n      return 'float32array';\n    case 'Float64Array':\n      return 'float64array';\n  }\n  if (isGeneratorObj(val)) {\n    return 'generator';\n  }\n\n  // Non-plain objects\n  type = toString.call(val);\n  switch (type) {\n    case '[object Object]':\n      return 'object';\n    // iterators\n    case '[object Map Iterator]':\n      return 'mapiterator';\n    case '[object Set Iterator]':\n      return 'setiterator';\n    case '[object String Iterator]':\n      return 'stringiterator';\n    case '[object Array Iterator]':\n      return 'arrayiterator';\n  }\n\n  // other\n  return type.slice(8, -1).toLowerCase().replace(/\\s/g, '');\n};\nfunction ctorName(val) {\n  return typeof val.constructor === 'function' ? val.constructor.name : null;\n}\nfunction isArray(val) {\n  if (Array.isArray) return Array.isArray(val);\n  return val instanceof Array;\n}\nfunction isError(val) {\n  return val instanceof Error || typeof val.message === 'string' && val.constructor && typeof val.constructor.stackTraceLimit === 'number';\n}\nfunction isDate(val) {\n  if (val instanceof Date) return true;\n  return typeof val.toDateString === 'function' && typeof val.getDate === 'function' && typeof val.setDate === 'function';\n}\nfunction isRegexp(val) {\n  if (val instanceof RegExp) return true;\n  return typeof val.flags === 'string' && typeof val.ignoreCase === 'boolean' && typeof val.multiline === 'boolean' && typeof val.global === 'boolean';\n}\nfunction isGeneratorFn(name, val) {\n  return ctorName(name) === 'GeneratorFunction';\n}\nfunction isGeneratorObj(val) {\n  return typeof val.throw === 'function' && typeof val.return === 'function' && typeof val.next === 'function';\n}\nfunction isArguments(val) {\n  try {\n    if (typeof val.length === 'number' && typeof val.callee === 'function') {\n      return true;\n    }\n  } catch (err) {\n    if (err.message.indexOf('callee') !== -1) {\n      return true;\n    }\n  }\n  return false;\n}\n\n/**\n * If you need to support Safari 5-7 (8-10 yr-old browser),\n * take a look at https://github.com/feross/is-buffer\n */\n\nfunction isBuffer(val) {\n  if (val.constructor && typeof val.constructor.isBuffer === 'function') {\n    return val.constructor.isBuffer(val);\n  }\n  return false;\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/kind-of/index.js?");

/***/ }),

/***/ "./node_modules/set-value/index.js":
/*!*****************************************!*\
  !*** ./node_modules/set-value/index.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("/*!\n * set-value <https://github.com/jonschlinkert/set-value>\n *\n * Copyright (c) 2014-2018, Jon Schlinkert.\n * Released under the MIT License.\n */\n\n\n\nvar isPlain = __webpack_require__(/*! is-plain-object */ \"./node_modules/is-plain-object/index.js\");\nfunction set(target, path, value, options) {\n  if (!isObject(target)) {\n    return target;\n  }\n  var opts = options || {};\n  var isArray = Array.isArray(path);\n  if (!isArray && typeof path !== 'string') {\n    return target;\n  }\n  var merge = opts.merge;\n  if (merge && typeof merge !== 'function') {\n    merge = Object.assign;\n  }\n  var keys = (isArray ? path : split(path, opts)).filter(isValidKey);\n  var len = keys.length;\n  var orig = target;\n  if (!options && keys.length === 1) {\n    result(target, keys[0], value, merge);\n    return target;\n  }\n  for (var i = 0; i < len; i++) {\n    var prop = keys[i];\n    if (!isObject(target[prop])) {\n      target[prop] = {};\n    }\n    if (i === len - 1) {\n      result(target, prop, value, merge);\n      break;\n    }\n    target = target[prop];\n  }\n  return orig;\n}\nfunction result(target, path, value, merge) {\n  if (merge && isPlain(target[path]) && isPlain(value)) {\n    target[path] = merge({}, target[path], value);\n  } else {\n    target[path] = value;\n  }\n}\nfunction split(path, options) {\n  var id = createKey(path, options);\n  if (set.memo[id]) return set.memo[id];\n  var char = options && options.separator ? options.separator : '.';\n  var keys = [];\n  var res = [];\n  if (options && typeof options.split === 'function') {\n    keys = options.split(path);\n  } else {\n    keys = path.split(char);\n  }\n  for (var i = 0; i < keys.length; i++) {\n    var prop = keys[i];\n    while (prop && prop.slice(-1) === '\\\\' && keys[i + 1] != null) {\n      prop = prop.slice(0, -1) + char + keys[++i];\n    }\n    res.push(prop);\n  }\n  set.memo[id] = res;\n  return res;\n}\nfunction createKey(pattern, options) {\n  var id = pattern;\n  if (typeof options === 'undefined') {\n    return id + '';\n  }\n  var keys = Object.keys(options);\n  for (var i = 0; i < keys.length; i++) {\n    var key = keys[i];\n    id += ';' + key + '=' + String(options[key]);\n  }\n  return id;\n}\nfunction isValidKey(key) {\n  if (typeof key !== 'string' && typeof key !== 'number') {\n    key = String(key);\n  }\n  return key !== '__proto__' && key !== 'constructor' && key !== 'prototype';\n}\nfunction isObject(val) {\n  return val !== null && (typeof val === 'object' || typeof val === 'function');\n}\nset.memo = {};\nmodule.exports = set;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/set-value/index.js?");

/***/ }),

/***/ "./node_modules/split-string/index.js":
/*!********************************************!*\
  !*** ./node_modules/split-string/index.js ***!
  \********************************************/
/***/ ((module) => {

"use strict";
eval("\n\nmodule.exports = function (input) {\n  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};\n  var fn = arguments.length > 2 ? arguments[2] : undefined;\n  if (typeof input !== 'string') throw new TypeError('expected a string');\n  if (typeof options === 'function') {\n    fn = options;\n    options = {};\n  }\n  var separator = options.separator || '.';\n  var ast = {\n    type: 'root',\n    nodes: [],\n    stash: ['']\n  };\n  var stack = [ast];\n  var state = {\n    input,\n    separator,\n    stack\n  };\n  var string = input;\n  var value, node;\n  var i = -1;\n  state.bos = () => i === 0;\n  state.eos = () => i === string.length;\n  state.prev = () => string[i - 1];\n  state.next = () => string[i + 1];\n  var quotes = options.quotes || [];\n  var openers = options.brackets || {};\n  if (options.brackets === true) {\n    openers = {\n      '[': ']',\n      '(': ')',\n      '{': '}',\n      '<': '>'\n    };\n  }\n  if (options.quotes === true) {\n    quotes = ['\"', '\\'', '`'];\n  }\n  var closers = invert(openers);\n  var keep = options.keep || (value => value !== '\\\\');\n  var block = () => state.block = stack[stack.length - 1];\n  var peek = () => string[i + 1];\n  var next = () => string[++i];\n  var append = value => {\n    state.value = value;\n    if (value && keep(value, state) !== false) {\n      state.block.stash[state.block.stash.length - 1] += value;\n    }\n  };\n  var closeIndex = (value, startIdx) => {\n    var idx = string.indexOf(value, startIdx);\n    if (idx > -1 && string[idx - 1] === '\\\\') {\n      idx = closeIndex(value, idx + 1);\n    }\n    return idx;\n  };\n  for (; i < string.length - 1;) {\n    state.value = value = next();\n    state.index = i;\n    block();\n\n    // handle escaped characters\n    if (value === '\\\\') {\n      if (peek() === '\\\\') {\n        append(value + next());\n      } else {\n        // if the next char is not '\\\\', allow the \"append\" function\n        // to determine if the backslashes should be added\n        append(value);\n        append(next());\n      }\n      continue;\n    }\n\n    // handle quoted strings\n    if (quotes.includes(value)) {\n      var pos = i + 1;\n      var idx = closeIndex(value, pos);\n      if (idx > -1) {\n        append(value); // append opening quote\n        append(string.slice(pos, idx)); // append quoted string\n        append(string[idx]); // append closing quote\n        i = idx;\n        continue;\n      }\n      append(value);\n      continue;\n    }\n\n    // handle opening brackets, if not disabled\n    if (options.brackets !== false && openers[value]) {\n      node = {\n        type: 'bracket',\n        nodes: []\n      };\n      node.stash = keep(value) !== false ? [value] : [''];\n      node.parent = state.block;\n      state.block.nodes.push(node);\n      stack.push(node);\n      continue;\n    }\n\n    // handle closing brackets, if not disabled\n    if (options.brackets !== false && closers[value]) {\n      if (stack.length === 1) {\n        append(value);\n        continue;\n      }\n      append(value);\n      node = stack.pop();\n      block();\n      append(node.stash.join(''));\n      continue;\n    }\n\n    // push separator onto stash\n    if (value === separator && state.block.type === 'root') {\n      if (typeof fn === 'function' && fn(state) === false) {\n        append(value);\n        continue;\n      }\n      state.block.stash.push('');\n      continue;\n    }\n\n    // append value onto the last string on the stash\n    append(value);\n  }\n  node = stack.pop();\n  while (node !== ast) {\n    if (options.strict === true) {\n      var column = i - node.stash.length + 1;\n      throw new SyntaxError(\"Unmatched: \\\"\".concat(node.stash[0], \"\\\", at column \").concat(column));\n    }\n    value = node.parent.stash.pop() + node.stash.join('.');\n    node.parent.stash = node.parent.stash.concat(value.split('.'));\n    node = stack.pop();\n  }\n  return node.stash;\n};\nfunction invert(obj) {\n  var inverted = {};\n  for (var key of Object.keys(obj)) inverted[obj[key]] = key;\n  return inverted;\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/split-string/index.js?");

/***/ }),

/***/ "./node_modules/union-value/index.js":
/*!*******************************************!*\
  !*** ./node_modules/union-value/index.js ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("\n\nvar get = __webpack_require__(/*! get-value */ \"./node_modules/get-value/index.js\");\nvar set = __webpack_require__(/*! set-value */ \"./node_modules/set-value/index.js\");\nvar isObject = val => {\n  return val != null && typeof val === 'object' && !Array.isArray(val);\n};\nvar flatten = function flatten() {\n  var res = [];\n  var flat = arr => {\n    for (var ele of arr) Array.isArray(ele) ? flat(ele, res) : res.push(ele);\n  };\n  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {\n    args[_key] = arguments[_key];\n  }\n  flat(args);\n  return res;\n};\nvar unique = arr => arr.filter((v, i) => arr.indexOf(v) === i);\nvar union = function union() {\n  return unique(flatten(...arguments));\n};\nvar first = function first() {\n  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {\n    args[_key2] = arguments[_key2];\n  }\n  return args.find(v => v != null);\n};\nmodule.exports = (obj, prop, value) => {\n  if (!isObject(obj)) {\n    throw new TypeError('expected the first argument to be an object');\n  }\n  if (typeof prop !== 'string') {\n    throw new TypeError('expected the second argument to be a string');\n  }\n  var arr = [].concat(first(get(obj, prop), []));\n  set(obj, prop, union(arr, [].concat(first(value, []))));\n  return obj;\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/union-value/index.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./DragAndDrop/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SuhiDragAndDropPCF.DragAndDrop', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DragAndDrop);
} else {
	var SuhiDragAndDropPCF = SuhiDragAndDropPCF || {};
	SuhiDragAndDropPCF.DragAndDrop = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DragAndDrop;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}